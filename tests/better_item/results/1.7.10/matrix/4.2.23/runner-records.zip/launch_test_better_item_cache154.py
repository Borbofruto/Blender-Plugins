import bpy,runpy,traceback
from pathlib import Path
def run():
 try:
  area=next(a for a in bpy.context.screen.areas if a.type=="VIEW_3D");region=next(r for r in area.regions if r.type=="WINDOW")
  with bpy.context.temp_override(area=area,region=region):runpy.run_path('D:\\Codex-BetterItem-1710-Qualification-2\\results\\4.2.23\\test_better_item_cache154.py',run_name="__main__")
 except Exception:
  traceback.print_exc();Path('D:\\Codex-BetterItem-1710-Qualification-2\\results\\4.2.23\\test_better_item_cache154.py.failed').write_text(traceback.format_exc(),encoding="utf-8")
 window=next(iter(bpy.context.window_manager.windows))
 with bpy.context.temp_override(window=window):bpy.ops.wm.quit_blender()
 return None
bpy.app.timers.register(run,first_interval=1)
