import sys as _compat_sys
_compat_sys.dont_write_bytecode=True
from pathlib import Path as _CompatPath
_compat_sys.path.insert(0,str(_CompatPath(__file__).resolve().parent))
"""Observe equivalent panel states; not a release acceptance matrix."""
import json,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
import bpy
import better_item as addon
from better_item import distribution as d
from better_item.math_core import BetterItemError
addon.register()
ctx=bpy.context;s=ctx.scene.better_item
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
objects=[]
for x in (3,8):
    bpy.ops.mesh.primitive_cube_add(location=(x,0,0));objects.append(ctx.object)
for obj in objects:obj.select_set(True)
ctx.view_layer.objects.active=objects[0]
s.arrange_reference_mode='INDIVIDUAL';s.arrange_origin='GLOBAL';s.arrange_orientation='GLOBAL'
s.distribution_method='OFFSET';s.distribution_mode='ORIGINS';s.axes=(True,False,False)
ctx.view_layer.update()
class Layout:
    def __init__(self):self.labels=[]
    def box(self,**kw):return self
    def row(self,**kw):return self
    def split(self,**kw):return self
    def column(self,**kw):return self
    def prop(self,*a,**kw):pass
    def label(self,**kw):self.labels.append(kw.get('text',''))
    def operator(self,*a,**kw):return SimpleNamespace()
rows=[]
def observe(name):
    d.clear_inspection();result=d.inspect_spacing(ctx,objects)
    layout=Layout();d.draw(layout,ctx)
    cause=None
    try:d.plan(ctx,objects)
    except BetterItemError as exc:cause=str(exc)
    rows.append({'case':name,'status':result[0],'value':result[1],
        'diagnostic':str(getattr(result,'diagnostic','')),'plan_refusal':cause,'labels':layout.labels})
s.axes=(False,False,False);observe('offset_no_axes_complete_references')
s.axes=(True,False,False);s.distribution_method='ENDPOINT';s.distribution_mode='ORIGINS'
s.endpoint_path='SEGMENT';s.distribution_start_override=False;s.distribution_end.mode='MANUAL';s.distribution_end.position=(0,0,0)
observe('endpoint_coincident_complete_references')
s.distribution_end.position=(1,0,0);s.endpoint_path='AXIS';s.axes=(False,False,False)
observe('endpoint_axis_missing_complete_references')
result={'passed':True,'purpose':'observation only; not release acceptance','blender':bpy.app.version_string,'module':addon.__file__,'cases':rows}
Path(__file__).with_suffix('.results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('VC VG DIAGNOSTIC OBSERVATIONS',json.dumps(result))
